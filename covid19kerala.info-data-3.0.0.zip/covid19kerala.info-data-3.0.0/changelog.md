### 3.0.0 
* Snapshot till 2020-06-05
* Schema changed with an addition of a field.

### 2.5.0 
* Snapshot till 2020-06-03
* snapshot.txt file with snapshot identifier

### 2.4.0 
* Snapshot till 2020-05-31

### 2.3.0 
* Snapshot till 2020-05-24
* Minor schema fixes

### 2.2.0
* Snapshot till 2020-05-22

### 2.1.0
* Snapshot till 2020-05-13

### 2.0.1
* Minor fixes in datapackage and schema JSON
* Image link for datapackage
* Snapshot till 2020-05-08

### 2.0.0
* Snapshot till 2020-05-08
* Included age dataset

### 1.1.0
* Snapshot till 2020-05-07
* Fixed and improved schema
* Added changelog
* version.txt file
* Complete tabular-data-package for individual csv

### 1.0.0
* Intial release
* Snapshot till 2020-05-07
* Daily summary
* District summary
* Hotspots
* Patient data